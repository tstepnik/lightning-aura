({
    init: function (cmp, event, helper) {
        cmp.set('v.columns', [
            {label: 'Account Id', fieldName: 'recordId', type: 'text'},
            {label: 'Account name', fieldName: 'name', type: 'text'},
            {label: 'Country', fieldName: 'country', type: 'text'},
        ]);
    },

    handleEvent: function(cmp, event, helper) {
        helper.handleEvent(cmp,event);
    },
});